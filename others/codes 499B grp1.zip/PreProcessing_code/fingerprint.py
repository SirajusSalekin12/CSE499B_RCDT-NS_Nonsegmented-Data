import numpy as np
import scipy.io as sio
import os
from skimage.transform import resize  # Importing skimage for resizing images
from scipy.io import loadmat

# Load the .npy files
img_real = np.load('dataset_FVC2000_DB4_B/dataset/np_data/img_real.npy')
img_train = np.load('dataset_FVC2000_DB4_B/dataset/np_data/img_train.npy')
label_real = np.load('dataset_FVC2000_DB4_B/dataset/np_data/label_real.npy')
label_train = np.load('dataset_FVC2000_DB4_B/dataset/np_data/label_train.npy')

# Convert labels to integers (Fixes DeprecationWarning in NumPy 1.25+)
label_real = np.squeeze(label_real).astype(int)  # Ensure it's a 1D array
label_train = np.squeeze(label_train).astype(int)

# Get unique class labels
classes = np.unique(label_train)

# Prepare directories to save the .mat files
output_dir = './data/fingerprint3'
train_dir = os.path.join(output_dir, 'training')
test_dir = os.path.join(output_dir, 'testing')
os.makedirs(train_dir, exist_ok=True)
os.makedirs(test_dir, exist_ok=True)

# Function to save images by class into .mat files
def save_images_by_class(images, labels, output_dir):
    images_by_class = {class_label: [] for class_label in classes}

    # Organize images by class
    for i in range(len(images)):
        label = int(labels[i])  # Extract integer safely
        img_resized = resize(images[i], (25, 25), anti_aliasing=True)

        # Ensure correct shape: (25, 25)
        img_resized = img_resized[:, :, np.newaxis] if img_resized.ndim == 2 else img_resized
        images_by_class[label].append(img_resized.squeeze())  # Remove unnecessary dimensions

    # Save each class's images into separate .mat files
    for class_label, images in images_by_class.items():
        # Stack images: Ensuring (25, 25, N)
        images_array = np.stack(images, axis=-1)  # Final shape should be (25, 25, N)
        print(f"Saving class {class_label} with shape: {images_array.shape}")  # Debugging info

        # Save .mat file
        class_data = {"xxO": images_array}
        file_path = os.path.join(output_dir, f"dataORG_{class_label}.mat")
        sio.savemat(file_path, class_data)

# Save images for real fingerprints (test set) and training fingerprints
save_images_by_class(img_real, label_real, test_dir)  # Test set
save_images_by_class(img_train, label_train, train_dir)  # Train set

print("MAT files for each class saved successfully!")

# Load one example .mat file and check its shape
example_class = int(classes[0])  # Pick the first class
datafile = os.path.join(test_dir, f"dataORG_{example_class}.mat")
data = loadmat(datafile)
xxO = data['xxO']

print(f"Shape of xxO: {xxO.shape}")  # Expected: (25, 25, N)
