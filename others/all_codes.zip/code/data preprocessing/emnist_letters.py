import os
import numpy as np
import pandas as pd
import scipy.io as sio

# Define file paths
train_csv_path = "emnist input/emnist-letters-train.csv"
test_csv_path = "emnist input/emnist-letters-test.csv"
mapping_path = "emnist input/emnist-letters-mapping.txt"

# Load data
train_data = pd.read_csv(train_csv_path, header=None)
test_data = pd.read_csv(test_csv_path, header=None)
mapping = np.loadtxt(mapping_path, dtype=int)

# Extract images and labels
train_labels = train_data.iloc[:, 0].values
test_labels = test_data.iloc[:, 0].values
train_images = train_data.iloc[:, 1:].values.reshape(-1, 28, 28).astype(np.uint8)
test_images = test_data.iloc[:, 1:].values.reshape(-1, 28, 28).astype(np.uint8)

# Create a dictionary mapping EMNIST labels (1-26) to zero-based indices (0-25)
label_mapping = {mapping[i, 0]: i for i in range(len(mapping))}

# Convert labels using mapping
train_labels = np.array([label_mapping[label] for label in train_labels])
test_labels = np.array([label_mapping[label] for label in test_labels])

# Define save directory
output_dir = "./data/emnist_letters"
os.makedirs(os.path.join(output_dir, "training"), exist_ok=True)
os.makedirs(os.path.join(output_dir, "testing"), exist_ok=True)

# Function to save data in .mat files
def save_mat_files(images, labels, phase):
    unique_classes = np.arange(26)  # Ensure we cover all classes from 0 to 25
    for class_idx in unique_classes:
        class_images = images[labels == class_idx]
        class_data = {"xxO": class_images.transpose(1, 2, 0)}  # Shape: (H, W, N)
        file_path = os.path.join(output_dir, phase, f"dataORG_{class_idx}.mat")
        sio.savemat(file_path, class_data)

# Save training and testing data
save_mat_files(train_images, train_labels, "training")
save_mat_files(test_images, test_labels, "testing")

print("MAT files saved successfully!")
