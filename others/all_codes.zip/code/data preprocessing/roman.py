import os
import numpy as np
import scipy.io as sio
from PIL import Image

# Define paths
base_dir = "roman/Roman_numbers"  # Root directory for the dataset
output_dir = "./data/roman_numbers"
os.makedirs(os.path.join(output_dir, "training"), exist_ok=True)
os.makedirs(os.path.join(output_dir, "testing"), exist_ok=True)

# Roman numeral class mapping
roman_numerals = ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"]  # Roman numerals for 1 to 10

# Valid image extensions to process
valid_image_extensions = [".jpg", ".jpeg", ".png", ".bmp", ".gif"]

# Resize function
def process_image(image_path):
    img = Image.open(image_path).convert("L")  # Convert to grayscale
    img_resized = img.resize((28, 28), Image.LANCZOS)  # Resize to 28x28
    return np.array(img_resized, dtype=np.uint8)

# Organize images by class (Roman numeral)
images_by_class = {}
for class_idx, roman in enumerate(roman_numerals, 1):  # Start from 1 for Roman numeral 'i'
    for phase in ['train', 'test']:  # Loop over train and test folders
        class_folder = os.path.join(base_dir, phase, roman)  # Folder path for the Roman numeral class
        if os.path.exists(class_folder):
            if class_idx not in images_by_class:
                images_by_class[class_idx] = []
            for filename in os.listdir(class_folder):
                img_path = os.path.join(class_folder, filename)
                # Skip files that are not valid image types
                if any(filename.lower().endswith(ext) for ext in valid_image_extensions):
                    images_by_class[class_idx].append(process_image(img_path))

# Save images into .mat files
def save_mat_files(images_by_class, phase):
    for class_idx, images in images_by_class.items():
        images_array = np.stack(images, axis=-1)  # Shape: (28, 28, N)
        class_data = {"xxO": images_array}
        file_path = os.path.join(output_dir, phase, f"dataORG_{class_idx}.mat")
        sio.savemat(file_path, class_data)

# Split dataset (assuming 80% training, 20% testing)
train_images_by_class = {}
test_images_by_class = {}
for class_idx, images in images_by_class.items():
    split_idx = int(len(images) * 0.8)
    train_images_by_class[class_idx] = images[:split_idx]
    test_images_by_class[class_idx] = images[split_idx:]

# Save training and testing data
save_mat_files(train_images_by_class, "training")
save_mat_files(test_images_by_class, "testing")

print("MAT files saved successfully!")
