import os
import numpy as np
import pandas as pd
import scipy.io as sio
from PIL import Image

# Define file paths
image_folder = "bangla/bangla digit/bangla-mnist/labeled"  # Update with actual image folder path
label_csv_path = "bangla/bangla digit/labels.csv"

# Load labels
labels_df = pd.read_csv(label_csv_path)
labels_df["digit"] = labels_df["digit"].astype(int)  # Ensure labels are integers

# Define save directory
output_dir = "./data/custom_dataset"
os.makedirs(os.path.join(output_dir, "training"), exist_ok=True)
os.makedirs(os.path.join(output_dir, "testing"), exist_ok=True)

# Resize function
def process_image(image_path):
    img = Image.open(image_path).convert("L")  # Convert to grayscale
    img_resized = img.resize((28, 28), Image.LANCZOS)  # Resize to 28x28
    return np.array(img_resized, dtype=np.uint8)

# Organize images by class
images_by_class = {}
for _, row in labels_df.iterrows():
    img_path = os.path.join(image_folder, row["filename"])
    if os.path.exists(img_path):
        class_idx = row["digit"]  # Use digit directly as class index
        if class_idx not in images_by_class:
            images_by_class[class_idx] = []
        images_by_class[class_idx].append(process_image(img_path))

# Save images into .mat files
def save_mat_files(images_by_class, phase):
    for class_idx, images in images_by_class.items():
        images_array = np.stack(images, axis=-1)  # Shape: (28, 28, N)
        class_data = {"xxO": images_array}
        file_path = os.path.join(output_dir, phase, f"vdataORG_{class_idx}.mat")
        sio.savemat(file_path, class_data)

# Split dataset (assuming 80% training, 20% testing)
train_images_by_class = {}
test_images_by_class = {}
for class_idx, images in images_by_class.items():
    split_idx = int(len(images) * 0.8)
    train_images_by_class[class_idx] = images[:split_idx]
    test_images_by_class[class_idx] = images[split_idx:]

# Save training and testing data
save_mat_files(train_images_by_class, "training")
save_mat_files(test_images_by_class, "testing")

print("MAT files saved successfully!")
